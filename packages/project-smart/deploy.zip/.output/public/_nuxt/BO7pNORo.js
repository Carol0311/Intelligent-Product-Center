import{_ as t,c as r,o as n,Q as s,d as a}from"#entry";const l={};function c(e,o){return n(),r("div",null,[s(e.$slots,"header",{},()=>[o[0]||(o[0]=a("自定义布局--头部",-1))]),s(e.$slots,"default")])}const f=t(l,[["render",c]]);export{f as default};
//# sourceMappingURL=BO7pNORo.js.map
